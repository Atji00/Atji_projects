package sda.traitement
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.types._

object ServiceVente {
  implicit class DataFrameUtils(dataFrame: DataFrame) {

    def formatter()= {
      dataFrame.withColumn("HTT", split(col("HTT_TVA"), "\\|")(0))
        .withColumn("TVA", split(col("HTT_TVA"), "\\|")(1))
        .withColumn("HTT", regexp_replace(col("HTT"), ",", "."))
        .withColumn("TVA", regexp_replace(col("TVA"), ",", "."))
    }

    def calculTTC () : DataFrame ={
      /*..........................coder ici...............................*/
      dataFrame.withColumn("TTC", round(col("HTT") + (col("TVA") * col("HTT")) , 2))
        .drop("HTT", "TVA")
    }
    def extractDateEndContratVille(): DataFrame = {
      val schema_MetaTransaction = new StructType()
        .add("Ville", StringType, false)
        .add("Date_End_contrat", StringType, false)
      val schema = new StructType()
        .add("MetaTransaction", ArrayType(schema_MetaTransaction), true)
      /*..........................coder ici...............................*/
      dataFrame.withColumn("fromJson_MetaData", from_json(col("MetaData"), schema)) // Parser la colonne JSON
        .withColumn("Ville", expr("fromJson_MetaData.MetaTransaction[0].Ville")) // Extraire la Ville
        .withColumn("Date_End_contrat_full", expr("fromJson_MetaData.MetaTransaction[0].Date_End_contrat")) // Extraire la date complète
        .withColumn(
          "Date_End_contrat",
          regexp_extract(col("Date_End_contrat_full"), "(\\d{4}-\\d{2}-\\d{2})", 1) // Extraire uniquement la partie YYYY-MM-DD
        )
        .drop("fromJson_MetaData", "Date_End_contrat_full") // Nettoyer les colonnes temporaires
        .drop("MetaData")

    }

    def contratStatus(): DataFrame = {
      /*..........................coder ici...............................*/
      dataFrame.withColumn(
        "Contrat_Status",
        when(to_date(col("Date_End_contrat"), "yyyy-MM-dd").lt(current_date()), "Expired") // Si la date de fin est passée
          .otherwise("Actif") // Sinon, actif
      )

    }


  }
}
