package sda.reader
import org.apache.spark.sql.{DataFrame, SparkSession}
case class XmlReader(path: String,
                     rowTag: Option[String] = None,
                     rootTag: Option[String] = None)

  extends Reader {
  val format = "com.databricks.spark.xml"
  val tag ="client"

  def read()(implicit spark: SparkSession): DataFrame = {
    val reader = spark.read.format(format)

    // Ajouter les options si elles sont définies
    rowTag.foreach(tag => reader.option("rowTag", tag))
    rootTag.foreach(tag => reader.option("rootTag", tag))

    reader.load(path)
  }
}



