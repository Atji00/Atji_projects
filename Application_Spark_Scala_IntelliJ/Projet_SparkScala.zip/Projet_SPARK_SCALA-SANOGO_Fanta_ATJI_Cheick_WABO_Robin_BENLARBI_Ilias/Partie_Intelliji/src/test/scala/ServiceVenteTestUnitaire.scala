import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.types._
import org.apache.spark.sql.functions._
import org.scalatest.BeforeAndAfterAll
import org.scalatest.funsuite.AnyFunSuite
import sda.traitement.ServiceVente.DataFrameUtils


class ServiceVenteTestUnitaire extends AnyFunSuite with BeforeAndAfterAll {

        // Creation des variables de la class
        var spark: SparkSession = _
        var testdata: DataFrame = _

        // Configuration des éléments communs aux tests avec beforAll
        override def beforeAll(): Unit = {

                // Création de la Session Spark pour le test
                spark = SparkSession.builder
                                    .appName("ServiceVenteTestUnitaire")
                                    .config("spark.master", "local")
                                    .getOrCreate()

                // Chargement  des données test
                testdata = spark.read.format("csv")
                                     .option("header", "true")
                                     .option("delimiter",";")
                                     .load("src/test/testresources/testdata.txt")
        }

        // Test1: sur la methode formatter de ServiceVente
        test(" Test1 sur la methode formatter") {

                val assertformatter = spark.read.format("csv")
                                                .option("header", "true")
                                                .option("delimiter",";")
                                                .load("src/test/testresources/AssertFormatterOutput.txt")
                val outputformatter = testdata.formatter()

                assert(outputformatter.select("HTT","TVA").except(assertformatter).isEmpty &&
                       assertformatter.except(outputformatter.select("HTT","TVA")).isEmpty)
        }

        // Test2: sur la methode calculTTC de ServiceVente
        test(" Test2 sur la methode calculTTC") {

                val assertcalcul = spark.read.format("csv")
                                        .option("header", "true")
                                        .option("delimiter",";")
                                        .load("src/test/testresources/AssertCalculttcOutput.txt")
                val outputcalcul = testdata.formatter().calculTTC()

                assert(outputcalcul.select("HTT_TVA", "TTC").except(assertcalcul).isEmpty &&
                       assertcalcul.except(outputcalcul.select("HTT_TVA", "TTC")).isEmpty)
        }

        // Test3: sur la methode extractDateEndContratVille de ServiceVente
        test(" Test3 sur la methode ExtractDateEndContratVille") {

                val assertextract = spark.read.format("csv")
                                          .option("header", "true")
                                          .option("delimiter",";")
                                          .load("src/test/testresources/AssertExtractDateVilleOutput.txt")
                val outputextract = testdata.extractDateEndContratVille()

                assert(outputextract.select("Ville","Date_End_contrat").except(assertextract).isEmpty &&
                        assertextract.except(outputextract.select("Ville","Date_End_contrat")).isEmpty)
        }

        // Test4: sur la methode ContratStatus de ServiceVente
        test(" Test4 sur la methode ContratStatus") {

                val assertcontrat = spark.read.format("csv")
                                          .option("header", "true")
                                          .option("delimiter",";")
                                          .load("src/test/testresources/AssertContratStatusOutput.txt")
                val outputcontrat = testdata.extractDateEndContratVille().contratStatus()

                assert(outputcontrat.select("Date_End_contrat","Contrat_Status").except(assertcontrat).isEmpty &&
                        assertcontrat.except(outputcontrat.select("Date_End_contrat","Contrat_Status")).isEmpty)
        }



        // Nettoyage de la mémoire et arrêt de la Session Spark après exécution des tests
        override def afterAll(): Unit = {
                if (spark != null) spark.stop()
        }

}
